import React, { Component } from 'react';
import './App.css';
import Teams from './FavouriteTeams/index';

class App extends Component {
  render() {
    return (
        <div>
          <Teams />
        </div>
    );
  }
}

export default App;

import React from "react";
import { connect } from 'react-redux';
import Ionicon from 'react-ionicons';
import { bindActionCreators } from 'redux';
import * as commissionsSummaryActions from './actions.js';
import './style.css';

class TeamDetails extends React.Component {
    componentDidMount(){
        this.props.actions.fetchTeamLocationDetails()
    }

    render() {
        return(
            <div className="container">
                <div className="status_bar"></div>
                <div className="title_bar">
                    <span className="icon" onClick={this.props.changeteam} ><Ionicon icon="ios-arrow-back" fontSize="24px" color="#aaaaaa" /></span>
                    <h1 className="teamName">Leanne Graham</h1>
                </div>
                <div className="title_bar">
                    <p>PICK FAVOURITE TEAMS</p>
                </div>
                <ul className="team_list">
                    { this.props.location && this.props.location.map((item, index) => {
                        return <li key={index}> <span className="icon"><Ionicon className="arrIcon" icon="md-american-football" fontSize="16px"/></span>{item.username}
                            <label class="checkContainer">
                                <input type="checkbox" className="checkbox" />
                                    <span class="checkmark"></span>
                            </label>
                        </li>
                    })}
                </ul>
            </div>
        );
    }
}

function mapStateToProps(state, ownProps) {debugger;
    return {
        location: state.teamReducers.teamLocations
    }
}

function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators(commissionsSummaryActions, dispatch)
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(TeamDetails);
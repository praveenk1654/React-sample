const Init={
teams:[],
teamLocations:[]
}
export default function teamReducer(state =Init, action) {
    switch (action.type) {
            case "GET_TEAMLOCATION":
            return {...state, teams: action.payload};
            case "GET_TEAMLOCATIONDETAILS":
            return {...state, teamLocations: action.payload}
        default:
            return state;
    }
}
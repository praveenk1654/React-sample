import { combineReducers } from "redux";
import teamReducers from "../FavouriteTeams/reducers"

const combinedReducer = combineReducers({
    teamReducers
});

export default combinedReducer;

import React from "react";
import Ionicon from 'react-ionicons';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import TeamDetails from './teamDetails';
import * as actions from './actions.js';
import './style.css';

class Teams extends React.Component {

    constructor(props) {
        super(props)
        this.state = { edit: true }
        this.changeTeam = this.changeTeam.bind(this);
    }

    componentDidMount(){
        this.props.actions.fetchTeamlocation()
    }

    changeTeam(){
        this.setState({edit: !this.state.edit})
    }

    render() {
        return(
            <div>
                {this.state.edit ?
                <div className="container">
                    <div className="status_bar"></div>
                    <div className="title_bar">
                        <span className="icon"><Ionicon className="arrIcon" icon="ios-arrow-back" fontSize="24px" color="#aaaaaa" /></span>
                        <p>PICK FAVOURITE TEAMS</p>
                    </div>
                    <ul className="team_list">
                        {this.props.locations && this.props.locations.map((item, index) => {
                            return <li key={index} className="teamList" onClick={this.changeTeam}><span className="icon"><Ionicon icon="md-basketball" fontSize="16px" /></span>{item.name}</li>
                        })}
                    </ul>
                    <div className="btnContainer">
                        <button>Done</button>
                    </div>
                </div> : <TeamDetails changeteam={this.changeTeam}/>}
            </div>
        );
    }
}

    function mapStateToProps(state, ownProps) {
        return {
            locations: state.teamReducers.teams
        }
    }
    
    function mapDispatchToProps(dispatch) {
        return {
            actions: bindActionCreators(actions, dispatch)
        }
    }
    
    export default connect(mapStateToProps, mapDispatchToProps)(Teams);
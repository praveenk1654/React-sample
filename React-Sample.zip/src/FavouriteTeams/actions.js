import axios from 'axios';

const GET_TEAMLOCATION = "GET_TEAMLOCATION";
const GET_TEAMLOCATIONDETAILS = "GET_TEAMLOCATIONDETAILS";

export function updateComponentState(type, payload) {
    return { type, payload };
}

export function fetchTeamlocation(){debugger;
    return (dispatch) => {
        axios.get('https://jsonplaceholder.typicode.com/users')
        .then((data) => {
        dispatch(updateComponentState(GET_TEAMLOCATION,  data.data));
    })
}
}

export function fetchTeamLocationDetails(){debugger;
    return (dispatch) => {
        axios.get('https://jsonplaceholder.typicode.com/users')
        .then((data) => {debugger
            const teamLocations = data.data;
            dispatch(updateComponentState(GET_TEAMLOCATIONDETAILS, teamLocations));
        })
    }
}